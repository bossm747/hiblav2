const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config();

async function initDatabase() {
    try {
        // Connect to MySQL server (without database)
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST || 'localhost',
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || '',
            port: process.env.DB_PORT || 3306
        });

        console.log('Connected to MySQL server');

        // Create database if it doesn't exist
        await connection.execute(`CREATE DATABASE IF NOT EXISTS ${process.env.DB_NAME || 'salon_spa_db'}`);
        console.log('Database created or already exists');

        // Use the database
        await connection.execute(`USE ${process.env.DB_NAME || 'salon_spa_db'}`);
        
        // Create tables
        await createTables(connection);
        
        // Insert sample data
        await insertSampleData(connection);
        
        console.log('Database initialization completed successfully!');
        
    } catch (error) {
        console.error('Database initialization failed:', error);
    } finally {
        process.exit(0);
    }
}

async function createTables(connection) {
    // Users table
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS users (
            id INT PRIMARY KEY AUTO_INCREMENT,
            username VARCHAR(50) UNIQUE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role ENUM('admin', 'manager', 'staff', 'receptionist') NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT TRUE
        )
    `);

    // Staff table
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS staff (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT,
            first_name VARCHAR(50) NOT NULL,
            last_name VARCHAR(50) NOT NULL,
            phone VARCHAR(20),
            email VARCHAR(100),
            specialization VARCHAR(100),
            commission_rate DECIMAL(5,2) DEFAULT 0.00,
            hire_date DATE,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        )
    `);

    // Customers table
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS customers (
            id INT PRIMARY KEY AUTO_INCREMENT,
            first_name VARCHAR(50) NOT NULL,
            last_name VARCHAR(50) NOT NULL,
            email VARCHAR(100),
            phone VARCHAR(20),
            date_of_birth DATE,
            address TEXT,
            loyalty_points INT DEFAULT 0,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT TRUE
        )
    `);

    // Service categories
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS service_categories (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            color_code VARCHAR(7) DEFAULT '#3498DB',
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Services
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS services (
            id INT PRIMARY KEY AUTO_INCREMENT,
            category_id INT,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            duration_minutes INT NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES service_categories(id) ON DELETE SET NULL
        )
    `);

    // Appointments
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS appointments (
            id INT PRIMARY KEY AUTO_INCREMENT,
            customer_id INT NOT NULL,
            staff_id INT NOT NULL,
            service_id INT NOT NULL,
            appointment_date DATE NOT NULL,
            appointment_time TIME NOT NULL,
            duration_minutes INT NOT NULL,
            status ENUM('scheduled', 'confirmed', 'in_progress', 'completed', 'cancelled', 'no_show') DEFAULT 'scheduled',
            notes TEXT,
            total_amount DECIMAL(10,2),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES customers(id),
            FOREIGN KEY (staff_id) REFERENCES staff(id),
            FOREIGN KEY (service_id) REFERENCES services(id)
        )
    `);

    // Products
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS products (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            sku VARCHAR(50) UNIQUE,
            category VARCHAR(50),
            price DECIMAL(10,2) NOT NULL,
            cost DECIMAL(10,2) DEFAULT 0.00,
            stock_quantity INT DEFAULT 0,
            min_stock_level INT DEFAULT 5,
            supplier VARCHAR(100),
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    `);

    // Sales
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS sales (
            id INT PRIMARY KEY AUTO_INCREMENT,
            customer_id INT,
            staff_id INT,
            sale_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            subtotal DECIMAL(10,2) NOT NULL,
            tax_amount DECIMAL(10,2) DEFAULT 0.00,
            discount_amount DECIMAL(10,2) DEFAULT 0.00,
            total_amount DECIMAL(10,2) NOT NULL,
            payment_method ENUM('cash', 'card', 'check', 'online') DEFAULT 'cash',
            notes TEXT,
            FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
            FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL
        )
    `);

    // Sale items
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS sale_items (
            id INT PRIMARY KEY AUTO_INCREMENT,
            sale_id INT NOT NULL,
            product_id INT,
            service_id INT,
            quantity INT DEFAULT 1,
            unit_price DECIMAL(10,2) NOT NULL,
            total_price DECIMAL(10,2) NOT NULL,
            FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL
        )
    `);

    // Settings
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS settings (
            id INT PRIMARY KEY AUTO_INCREMENT,
            \`key\` VARCHAR(100) UNIQUE NOT NULL,
            \`value\` TEXT,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    `);

    console.log('All tables created successfully');
}

async function insertSampleData(connection) {
    // Check if data already exists
    const [users] = await connection.execute('SELECT COUNT(*) as count FROM users');
    if (users[0].count > 0) {
        console.log('Sample data already exists, skipping insertion');
        return;
    }

    // Create admin user
    const hashedPassword = await bcrypt.hash('admin123', 10);
    await connection.execute(
        'INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)',
        ['admin', 'admin@luxesalon.com', hashedPassword, 'admin']
    );

    // Create sample staff
    await connection.execute(
        'INSERT INTO staff (user_id, first_name, last_name, phone, email, specialization, commission_rate, hire_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [1, 'Sarah', 'Johnson', '555-0101', 'sarah@luxesalon.com', 'Hair Styling', 30.00, '2023-01-15']
    );

    // Create sample customers
    await connection.execute(
        'INSERT INTO customers (first_name, last_name, email, phone, loyalty_points) VALUES (?, ?, ?, ?, ?)',
        ['Emma', 'Davis', 'emma.davis@email.com', '555-1001', 150]
    );

    // Create service categories
    await connection.execute(
        'INSERT INTO service_categories (name, description, color_code) VALUES (?, ?, ?)',
        ['Hair Services', 'Hair cutting, styling, and treatments', '#E74C3C']
    );

    await connection.execute(
        'INSERT INTO service_categories (name, description, color_code) VALUES (?, ?, ?)',
        ['Spa Services', 'Massage, facials, and body treatments', '#3498DB']
    );

    // Create sample services
    await connection.execute(
        'INSERT INTO services (category_id, name, description, duration_minutes, price) VALUES (?, ?, ?, ?, ?)',
        [1, 'Women\'s Haircut', 'Professional haircut with styling', 45, 65.00]
    );

    await connection.execute(
        'INSERT INTO services (category_id, name, description, duration_minutes, price) VALUES (?, ?, ?, ?, ?)',
        [2, 'Swedish Massage', 'Relaxing full-body massage', 60, 85.00]
    );

    // Create sample products
    await connection.execute(
        'INSERT INTO products (name, description, sku, category, price, stock_quantity) VALUES (?, ?, ?, ?, ?, ?)',
        ['Shampoo', 'Professional salon shampoo', 'SHAM-001', 'Hair Care', 25.00, 50]
    );

    // Insert settings
    await connection.execute(
        'INSERT INTO settings (\`key\`, \`value\`, description) VALUES (?, ?, ?)',
        ['business_name', 'Luxe Salon & Spa', 'Business name displayed in the system']
    );

    console.log('Sample data inserted successfully');
}

// Run initialization
initDatabase();