// Global variables
let currentUser = null;
let authToken = localStorage.getItem('authToken');
let currentPage = 'dashboard';

// API configuration
const API_BASE_URL = 'http://localhost:3000/api';

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    if (authToken) {
        validateToken();
    } else {
        showLoginScreen();
    }
    
    // Event listeners
    document.getElementById('login-form').addEventListener('submit', handleLogin);
    document.getElementById('logout-btn').addEventListener('click', handleLogout);
    
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = e.target.dataset.page;
            if (page) {
                navigateToPage(page);
            }
        });
    });
});

// Authentication
async function validateToken() {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/validate`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            currentUser = data.user;
            showApp();
            loadDashboard();
        } else {
            localStorage.removeItem('authToken');
            showLoginScreen();
        }
    } catch (error) {
        console.error('Token validation error:', error);
        showLoginScreen();
    }
}

async function handleLogin(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const credentials = {
        username: formData.get('username'),
        password: formData.get('password')
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(credentials)
        });
        
        const data = await response.json();
        
        if (data.success) {
            authToken = data.accessToken;
            localStorage.setItem('authToken', authToken);
            currentUser = data.user;
            showApp();
            loadDashboard();
        } else {
            document.getElementById('login-error').textContent = data.message;
        }
    } catch (error) {
        console.error('Login error:', error);
        document.getElementById('login-error').textContent = 'Login failed. Please try again.';
    }
}

function handleLogout() {
    localStorage.removeItem('authToken');
    authToken = null;
    currentUser = null;
    showLoginScreen();
}

// UI Management
function showLoginScreen() {
    document.getElementById('login-screen').style.display = 'flex';
    document.getElementById('app').style.display = 'none';
}

function showApp() {
    document.getElementById('login-screen').style.display = 'none';
    document.getElementById('app').style.display = 'block';
    updateUserInfo();
}

function updateUserInfo() {
    if (currentUser) {
        document.getElementById('user-name').textContent = currentUser.username;
        document.getElementById('user-role').textContent = currentUser.role;
    }
}

function navigateToPage(page) {
    currentPage = page;
    
    // Update active nav
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.dataset.page === page) {
            link.classList.add('active');
        }
    });
    
    // Hide all pages
    document.querySelectorAll('.page').forEach(p => p.style.display = 'none');
    
    // Show selected page
    document.getElementById(`${page}-page`).style.display = 'block';
    
    // Load page data
    switch (page) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'appointments':
            loadAppointments();
            break;
        case 'customers':
            loadCustomers();
            break;
        case 'staff':
            loadStaff();
            break;
        case 'services':
            loadServices();
            break;
        case 'inventory':
            loadInventory();
            break;
        case 'sales':
            loadSales();
            break;
        case 'reports':
            loadReports();
            break;
    }
}

// Dashboard
async function loadDashboard() {
    try {
        const response = await fetch(`${API_BASE_URL}/reports/dashboard`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            updateDashboardStats(data.data);
            loadTodayAppointments();
        }
    } catch (error) {
        console.error('Dashboard load error:', error);
    }
}

function updateDashboardStats(stats) {
    document.getElementById('today-appointments').textContent = stats.todayAppointments;
    document.getElementById('today-revenue').textContent = `$${stats.todayRevenue}`;
    document.getElementById('active-customers').textContent = stats.activeCustomers;
    document.getElementById('low-stock-products').textContent = stats.lowStockProducts;
}

async function loadTodayAppointments() {
    try {
        const today = new Date().toISOString().split('T')[0];
        const response = await fetch(`${API_BASE_URL}/appointments?date=${today}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayTodayAppointments(data.data);
        }
    } catch (error) {
        console.error('Load today appointments error:', error);
    }
}

function displayTodayAppointments(appointments) {
    const container = document.getElementById('today-appointments-list');
    container.innerHTML = '';
    
    if (appointments.length === 0) {
        container.innerHTML = '<p class="no-data">No appointments scheduled for today</p>';
        return;
    }
    
    appointments.forEach(appointment => {
        const div = document.createElement('div');
        div.className = 'appointment-item';
        div.innerHTML = `
            <div class="appointment-time">${appointment.appointment_time}</div>
            <div class="appointment-details">
                <div class="customer-name">${appointment.customer_first_name} ${appointment.customer_last_name}</div>
                <div class="service-name">${appointment.service_name}</div>
                <div class="staff-name">with ${appointment.staff_name}</div>
            </div>
            <div class="appointment-status status-${appointment.status}">${appointment.status}</div>
        `;
        container.appendChild(div);
    });
}

// Appointments
async function loadAppointments() {
    try {
        const response = await fetch(`${API_BASE_URL}/appointments`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayAppointments(data.data);
        }
    } catch (error) {
        console.error('Load appointments error:', error);
    }
}

function displayAppointments(appointments) {
    const container = document.getElementById('appointments-list');
    container.innerHTML = '';
    
    if (appointments.length === 0) {
        container.innerHTML = '<p class="no-data">No appointments found</p>';
        return;
    }
    
    appointments.forEach(appointment => {
        const div = document.createElement('div');
        div.className = 'appointment-card';
        div.innerHTML = `
            <div class="appointment-header">
                <h4>${appointment.customer_first_name} ${appointment.customer_last_name}</h4>
                <span class="status-${appointment.status}">${appointment.status}</span>
            </div>
            <div class="appointment-body">
                <p><strong>Service:</strong> ${appointment.service_name}</p>
                <p><strong>Staff:</strong> ${appointment.staff_name}</p>
                <p><strong>Date:</strong> ${appointment.appointment_date}</p>
                <p><strong>Time:</strong> ${appointment.appointment_time}</p>
                <p><strong>Duration:</strong> ${appointment.duration_minutes} minutes</p>
                <p><strong>Amount:</strong> $${appointment.total_amount || '0.00'}</p>
            </div>
            <div class="appointment-actions">
                <button class="btn btn-sm btn-primary" onclick="editAppointment(${appointment.id})">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn btn-sm btn-danger" onclick="cancelAppointment(${appointment.id})">
                    <i class="fas fa-times"></i> Cancel
                </button>
            </div>
        `;
        container.appendChild(div);
    });
}

// Customers
async function loadCustomers() {
    try {
        const response = await fetch(`${API_BASE_URL}/customers`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayCustomers(data.data);
        }
    } catch (error) {
        console.error('Load customers error:', error);
    }
}

function displayCustomers(customers) {
    const container = document.getElementById('customers-list');
    container.innerHTML = '';
    
    if (customers.length === 0) {
        container.innerHTML = '<p class="no-data">No customers found</p>';
        return;
    }
    
    customers.forEach(customer => {
        const div = document.createElement('div');
        div.className = 'customer-card';
        div.innerHTML = `
            <div class="customer-info">
                <h4>${customer.first_name} ${customer.last_name}</h4>
                <p><i class="fas fa-phone"></i> ${customer.phone || 'N/A'}</p>
                <p><i class="fas fa-envelope"></i> ${customer.email || 'N/A'}</p>
                <p><i class="fas fa-calendar"></i> ${customer.total_appointments || 0} appointments</p>
                <p><i class="fas fa-star"></i> ${customer.loyalty_points || 0} points</p>
            </div>
            <div class="customer-actions">
                <button class="btn btn-sm btn-primary" onclick="editCustomer(${customer.id})">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn btn-sm btn-secondary" onclick="viewCustomer(${customer.id})">
                    <i class="fas fa-eye"></i> View
                </button>
            </div>
        `;
        container.appendChild(div);
    });
}

// Utility functions
function showModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

function hideModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Initialize other page loaders (placeholders for now)
async function loadStaff() {
    console.log('Loading staff...');
}

async function loadServices() {
    console.log('Loading services...');
}

async function loadInventory() {
    console.log('Loading inventory...');
}

async function loadSales() {
    console.log('Loading sales...');
}

async function loadReports() {
    console.log('Loading reports...');
}