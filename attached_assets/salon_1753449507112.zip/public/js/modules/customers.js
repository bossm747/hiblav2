// Customer Management Module
class CustomerManager {
    constructor() {
        this.customers = this.loadCustomers();
    }

    loadCustomers() {
        const saved = localStorage.getItem('customers');
        return saved ? JSON.parse(saved) : this.getSampleCustomers();
    }

    getSampleCustomers() {
        return [
            {
                id: 1,
                first_name: 'Sarah',
                last_name: 'Johnson',
                email: 'sarah.johnson@email.com',
                phone: '(555) 123-4567',
                address: '123 Main St, City, ST 12345',
                date_of_birth: '1985-06-15',
                loyalty_points: 250,
                total_visits: 12,
                last_visit: '2024-01-15',
                notes: 'Prefers organic products, sensitive skin'
            },
            {
                id: 2,
                first_name: 'Michael',
                last_name: 'Chen',
                email: 'm.chen@email.com',
                phone: '(555) 987-6543',
                address: '456 Oak Ave, City, ST 12345',
                date_of_birth: '1990-03-22',
                loyalty_points: 180,
                total_visits: 8,
                last_visit: '2024-01-10',
                notes: 'Regular haircut, prefers morning appointments'
            },
            {
                id: 3,
                first_name: 'Emma',
                last_name: 'Williams',
                email: 'emma.w@email.com',
                phone: '(555) 456-7890',
                address: '789 Pine Rd, City, ST 12345',
                date_of_birth: '1992-11-08',
                loyalty_points: 320,
                total_visits: 15,
                last_visit: '2024-01-12',
                notes: 'VIP customer, loves spa treatments'
            }
        ];
    }

    saveCustomers() {
        localStorage.setItem('customers', JSON.stringify(this.customers));
    }

    getAllCustomers() {
        return this.customers;
    }

    getCustomerById(id) {
        return this.customers.find(c => c.id === parseInt(id));
    }

    addCustomer(customer) {
        const newCustomer = {
            id: Math.max(...this.customers.map(c => c.id), 0) + 1,
            ...customer,
            loyalty_points: 0,
            total_visits: 0,
            created_at: new Date().toISOString()
        };
        this.customers.push(newCustomer);
        this.saveCustomers();
        return newCustomer;
    }

    updateCustomer(id, updates) {
        const index = this.customers.findIndex(c => c.id === parseInt(id));
        if (index !== -1) {
            this.customers[index] = { ...this.customers[index], ...updates };
            this.saveCustomers();
            return this.customers[index];
        }
        return null;
    }

    deleteCustomer(id) {
        const index = this.customers.findIndex(c => c.id === parseInt(id));
        if (index !== -1) {
            this.customers.splice(index, 1);
            this.saveCustomers();
            return true;
        }
        return false;
    }

    searchCustomers(query) {
        const searchTerm = query.toLowerCase();
        return this.customers.filter(customer =>
            customer.first_name.toLowerCase().includes(searchTerm) ||
            customer.last_name.toLowerCase().includes(searchTerm) ||
            customer.email.toLowerCase().includes(searchTerm) ||
            customer.phone.includes(searchTerm)
        );
    }
}

// Initialize customer manager
window.customerManager = new CustomerManager();