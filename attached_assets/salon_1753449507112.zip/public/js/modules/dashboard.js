// Dashboard Module
class DashboardManager {
    constructor() {
        this.init();
    }

    init() {
        this.renderDashboard();
    }

    renderDashboard() {
        const dashboard = document.getElementById('dashboard');
        dashboard.innerHTML = `
            <div class="dashboard-header">
                <h1>Dashboard</h1>
                <p>Welcome back! Here's what's happening today.</p>
            </div>
            
            <div class="dashboard-stats">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="today-appointments">0</h3>
                        <p>Today's Appointments</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="today-revenue">$0</h3>
                        <p>Today's Revenue</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="total-customers">0</h3>
                        <p>Total Customers</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="monthly-growth">0%</h3>
                        <p>Monthly Growth</p>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-content">
                <div class="recent-appointments">
                    <h2>Today's Appointments</h2>
                    <div id="appointments-list" class="appointments-list">
                        <!-- Appointments will be loaded here -->
                    </div>
                </div>
                
                <div class="quick-actions">
                    <h2>Quick Actions</h2>
                    <div class="action-buttons">
                        <button class="btn btn-primary" onclick="showPage('appointments')">
                            <i class="fas fa-plus"></i> New Appointment
                        </button>
                        <button class="btn btn-secondary" onclick="showPage('customers')">
                            <i class="fas fa-user-plus"></i> Add Customer
                        </button>
                        <button class="btn btn-success" onclick="showPage('sales')">
                            <i class="fas fa-cash-register"></i> New Sale
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        this.loadDashboardData();
    }

    loadDashboardData() {
        const today = new Date().toISOString().split('T')[0];
        const appointments = window.appointmentManager.getAppointmentsByDate(today);
        const customers = window.customerManager.getAllCustomers();
        
        // Update stats
        document.getElementById('today-appointments').textContent = appointments.length;
        document.getElementById('today-revenue').textContent = `$${this.calculateTodayRevenue(appointments)}`;
        document.getElementById('total-customers').textContent = customers.length;
        document.getElementById('monthly-growth').textContent = '+12%';
        
        // Load appointments list
        this.renderAppointmentsList(appointments);
    }

    calculateTodayRevenue(appointments) {
        return appointments.reduce((total, apt) => total + (apt.price || 0), 0);
    }

    renderAppointmentsList(appointments) {
        const listContainer = document.getElementById('appointments-list');
        
        if (appointments.length === 0) {
            listContainer.innerHTML = '<p class="no-data">No appointments scheduled for today.</p>';
            return;
        }

        const sortedAppointments = appointments.sort((a, b) => 
            a.appointment_time.localeCompare(b.appointment_time)
        );

        listContainer.innerHTML = sortedAppointments.map(apt => `
            <div class="appointment-item">
                <div class="appointment-time">${apt.appointment_time}</div>
                <div class="appointment-details">
                    <h4>${apt.customer_name}</h4>
                    <p>${apt.service_name} with ${apt.staff_name}</p>
                </div>
                <div class="appointment-status">
                    <span class="status-badge status-${apt.status}">${apt.status}</span>
                </div>
            </div>
        `).join('');
    }
}

// Initialize dashboard
window.dashboardManager = new DashboardManager();