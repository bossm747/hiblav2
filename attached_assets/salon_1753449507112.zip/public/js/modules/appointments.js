// Appointment Management Module
class AppointmentManager {
    constructor() {
        this.appointments = this.loadAppointments();
        this.services = this.loadServices();
        this.staff = this.loadStaff();
    }

    loadAppointments() {
        const saved = localStorage.getItem('appointments');
        return saved ? JSON.parse(saved) : this.getSampleAppointments();
    }

    loadServices() {
        return [
            { id: 1, name: 'Haircut & Style', duration: 60, price: 65, category: 'Hair' },
            { id: 2, name: 'Hair Color', duration: 120, price: 120, category: 'Hair' },
            { id: 3, name: 'Manicure', duration: 45, price: 35, category: 'Nails' },
            { id: 4, name: 'Pedicure', duration: 60, price: 45, category: 'Nails' },
            { id: 5, name: 'Facial Treatment', duration: 90, price: 95, category: 'Skincare' },
            { id: 6, name: 'Massage Therapy', duration: 60, price: 85, category: 'Spa' }
        ];
    }

    loadStaff() {
        return [
            { id: 1, first_name: 'Maria', last_name: 'Rodriguez', specialty: 'Hair Styling' },
            { id: 2, first_name: 'David', last_name: 'Kim', specialty: 'Color Specialist' },
            { id: 3, first_name: 'Lisa', last_name: 'Thompson', specialty: 'Nail Technician' },
            { id: 4, first_name: 'James', last_name: 'Wilson', specialty: 'Massage Therapist' }
        ];
    }

    getSampleAppointments() {
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        return [
            {
                id: 1,
                customer_id: 1,
                customer_name: 'Sarah Johnson',
                staff_id: 1,
                staff_name: 'Maria Rodriguez',
                service_id: 1,
                service_name: 'Haircut & Style',
                appointment_date: today.toISOString().split('T')[0],
                appointment_time: '09:00',
                duration: 60,
                price: 65,
                status: 'confirmed',
                notes: 'Regular client, prefers organic products'
            },
            {
                id: 2,
                customer_id: 2,
                customer_name: 'Michael Chen',
                customer_id: 2,
                staff_id: 2,
                staff_name: 'David Kim',
                service_id: 2,
                service_name: 'Hair Color',
                appointment_date: today.toISOString().split('T')[0],
                appointment_time: '14:00',
                duration: 120,
                price: 120,
                status: 'confirmed',
                notes: 'First time color, consultation needed'
            },
            {
                id: 3,
                customer_id: 3,
                customer_name: 'Emma Williams',
                staff_id: 4,
                staff_name: 'James Wilson',
                service_id: 6,
                service_name: 'Massage Therapy',
                appointment_date: tomorrow.toISOString().split('T')[0],
                appointment_time: '11:00',
                duration: 60,
                price: 85,
                status: 'pending',
                notes: 'VIP customer, deep tissue massage'
            }
        ];
    }

    saveAppointments() {
        localStorage.setItem('appointments', JSON.stringify(this.appointments));
    }

    getAllAppointments() {
        return this.appointments;
    }

    getAppointmentsByDate(date) {
        return this.appointments.filter(a => a.appointment_date === date);
    }

    getAppointmentsByStaff(staffId, date) {
        return this.appointments.filter(a => 
            a.staff_id === parseInt(staffId) && 
            a.appointment_date === date
        );
    }

    addAppointment(appointment) {
        const newAppointment = {
            id: Math.max(...this.appointments.map(a => a.id), 0) + 1,
            ...appointment,
            status: 'pending',
            created_at: new Date().toISOString()
        };
        this.appointments.push(newAppointment);
        this.saveAppointments();
        return newAppointment;
    }

    updateAppointment(id, updates) {
        const index = this.appointments.findIndex(a => a.id === parseInt(id));
        if (index !== -1) {
            this.appointments[index] = { ...this.appointments[index], ...updates };
            this.saveAppointments();
            return this.appointments[index];
        }
        return null;
    }

    cancelAppointment(id) {
        return this.updateAppointment(id, { status: 'cancelled' });
    }

    confirmAppointment(id) {
        return this.updateAppointment(id, { status: 'confirmed' });
    }

    getAvailableSlots(staffId, date) {
        const staff = this.staff.find(s => s.id === parseInt(staffId));
        if (!staff) return [];

        const workingHours = {
            start: '09:00',
            end: '18:00',
            slotDuration: 30 // minutes
        };

        const existingAppointments = this.getAppointmentsByStaff(staffId, date);
        const availableSlots = [];

        const [startHour, startMin] = workingHours.start.split(':').map(Number);
        const [endHour, endMin] = workingHours.end.split(':').map(Number);

        for (let hour = startHour; hour < endHour; hour++) {
            for (let minute = 0; minute < 60; minute += workingHours.slotDuration) {
                const time = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
                
                const isAvailable = !existingAppointments.some(apt => {
                    const [aptHour, aptMin] = apt.appointment_time.split(':').map(Number);
                    const aptEndTime = aptHour * 60 + aptMin + apt.duration;
                    const slotTime = hour * 60 + minute;
                    
                    return slotTime >= aptHour * 60 + aptMin && slotTime < aptEndTime;
                });

                if (isAvailable) {
                    availableSlots.push(time);
                }
            }
        }

        return availableSlots;
    }

    getUpcomingAppointments(days = 7) {
        const today = new Date();
        const endDate = new Date(today);
        endDate.setDate(endDate.getDate() + days);

        return this.appointments.filter(apt => {
            const aptDate = new Date(apt.appointment_date);
            return aptDate >= today && aptDate <= endDate && apt.status !== 'cancelled';
        });
    }
}

// Initialize appointment manager
window.appointmentManager = new AppointmentManager();