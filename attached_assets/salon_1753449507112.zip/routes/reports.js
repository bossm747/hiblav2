const express = require('express');
const { db } = require('../config/database');
const { authenticateToken, requireManager } = require('../middleware/auth');

const router = express.Router();

// Get dashboard summary
router.get('/dashboard', authenticateToken, async (req, res) => {
    try {
        const { date = new Date().toISOString().split('T')[0] } = req.query;
        
        // Today's appointments
        const [todayAppointments] = await db.query(
            'SELECT COUNT(*) as count FROM appointments WHERE appointment_date = ?',
            [date]
        );
        
        // Today's revenue
        const [todayRevenue] = await db.query(
            'SELECT COALESCE(SUM(total_amount), 0) as total FROM sales WHERE DATE(created_at) = ?',
            [date]
        );
        
        // Active customers
        const [activeCustomers] = await db.query(
            'SELECT COUNT(*) as count FROM customers WHERE is_active = 1'
        );
        
        // Low stock products
        const [lowStock] = await db.query(
            'SELECT COUNT(*) as count FROM products WHERE stock_quantity <= reorder_point AND is_active = 1'
        );
        
        res.json({
            success: true,
            data: {
                todayAppointments: todayAppointments.count,
                todayRevenue: todayRevenue.total,
                activeCustomers: activeCustomers.count,
                lowStockProducts: lowStock.count
            }
        });
    } catch (error) {
        console.error('Dashboard error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch dashboard data'
        });
    }
});

module.exports = router;