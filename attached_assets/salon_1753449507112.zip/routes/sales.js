const express = require('express');
const { db } = require('../config/database');
const { authenticateToken, requireReceptionist } = require('../middleware/auth');

const router = express.Router();

// Get sales transactions
router.get('/', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const { page = 1, limit = 10, start_date, end_date } = req.query;
        const offset = (page - 1) * limit;
        
        let sql = `
            SELECT s.*, 
                   c.first_name as customer_first_name,
                   c.last_name as customer_last_name,
                   st.first_name as staff_first_name,
                   st.last_name as staff_last_name
            FROM sales s
            LEFT JOIN customers c ON s.customer_id = c.id
            LEFT JOIN staff st ON s.staff_id = st.id
            WHERE 1=1
        `;
        
        const params = [];
        
        if (start_date && end_date) {
            sql += ' AND DATE(s.created_at) BETWEEN ? AND ?';
            params.push(start_date, end_date);
        }
        
        sql += ' ORDER BY s.created_at DESC LIMIT ? OFFSET ?';
        params.push(parseInt(limit), parseInt(offset));
        
        const sales = await db.query(sql, params);
        
        res.json({
            success: true,
            data: sales
        });
    } catch (error) {
        console.error('Get sales error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch sales'
        });
    }
});

module.exports = router;