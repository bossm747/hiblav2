const express = require('express');
const { db } = require('../config/database');
const { authenticateToken, requireReceptionist } = require('../middleware/auth');
const moment = require('moment');

const router = express.Router();

// Get appointments with filters
router.get('/', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const {
            page = 1,
            limit = 10,
            date,
            staff_id,
            customer_id,
            status,
            start_date,
            end_date
        } = req.query;

        const offset = (page - 1) * limit;
        let sql = `
            SELECT a.*, 
                   c.first_name as customer_first_name,
                   c.last_name as customer_last_name,
                   c.phone as customer_phone,
                   s.name as service_name,
                   s.duration_minutes,
                   CONCAT(st.first_name, ' ', st.last_name) as staff_name,
                   sa.total_amount,
                   sa.payment_status
            FROM appointments a
            JOIN customers c ON a.customer_id = c.id
            JOIN services s ON a.service_id = s.id
            JOIN staff st ON a.staff_id = st.id
            LEFT JOIN sales sa ON a.id = sa.appointment_id
            WHERE 1=1
        `;

        const params = [];

        if (date) {
            sql += ' AND a.appointment_date = ?';
            params.push(date);
        }

        if (staff_id) {
            sql += ' AND a.staff_id = ?';
            params.push(staff_id);
        }

        if (customer_id) {
            sql += ' AND a.customer_id = ?';
            params.push(customer_id);
        }

        if (status) {
            sql += ' AND a.status = ?';
            params.push(status);
        }

        if (start_date && end_date) {
            sql += ' AND a.appointment_date BETWEEN ? AND ?';
            params.push(start_date, end_date);
        }

        sql += ' ORDER BY a.appointment_date DESC, a.start_time DESC LIMIT ? OFFSET ?';
        params.push(parseInt(limit), parseInt(offset));

        const appointments = await db.query(sql, params);

        // Get total count
        let countSql = `
            SELECT COUNT(*) as total
            FROM appointments a
            JOIN customers c ON a.customer_id = c.id
            JOIN services s ON a.service_id = s.id
            JOIN staff st ON a.staff_id = st.id
            WHERE 1=1
        `;

        const countParams = [];
        
        if (date) {
            countSql += ' AND a.appointment_date = ?';
            countParams.push(date);
        }
        if (staff_id) countParams.push(staff_id);
        if (customer_id) countParams.push(customer_id);
        if (status) countParams.push(status);
        if (start_date && end_date) countParams.push(start_date, end_date);

        const [countResult] = await db.query(countSql, countParams);

        res.json({
            success: true,
            data: {
                appointments,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: countResult.total,
                    pages: Math.ceil(countResult.total / limit)
                }
            }
        });
    } catch (error) {
        console.error('Get appointments error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch appointments'
        });
    }
});

// Get appointment by ID
router.get('/:id', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const appointmentId = req.params.id;

        const [appointment] = await db.query(`
            SELECT a.*, 
                   c.first_name as customer_first_name,
                   c.last_name as customer_last_name,
                   c.email as customer_email,
                   c.phone as customer_phone,
                   s.name as service_name,
                   s.duration_minutes,
                   s.base_price,
                   CONCAT(st.first_name, ' ', st.last_name) as staff_name,
                   sa.total_amount,
                   sa.payment_method,
                   sa.payment_status,
                   sa.notes as sale_notes
            FROM appointments a
            JOIN customers c ON a.customer_id = c.id
            JOIN services s ON a.service_id = s.id
            JOIN staff st ON a.staff_id = st.id
            LEFT JOIN sales sa ON a.id = sa.appointment_id
            WHERE a.id = ?
        `, [appointmentId]);

        if (!appointment) {
            return res.status(404).json({
                success: false,
                message: 'Appointment not found'
            });
        }

        res.json({
            success: true,
            data: appointment
        });
    } catch (error) {
        console.error('Get appointment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch appointment'
        });
    }
});

// Create new appointment
router.post('/', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const {
            customer_id,
            staff_id,
            service_id,
            appointment_date,
            start_time,
            notes
        } = req.body;

        // Validate customer
        const customer = await db.findById('customers', customer_id);
        if (!customer || !customer.is_active) {
            return res.status(400).json({
                success: false,
                message: 'Invalid customer'
            });
        }

        // Validate staff
        const staff = await db.findById('staff', staff_id);
        if (!staff || !staff.is_active) {
            return res.status(400).json({
                success: false,
                message: 'Invalid staff member'
            });
        }

        // Validate service
        const service = await db.findById('services', service_id);
        if (!service || !service.is_active) {
            return res.status(400).json({
                success: false,
                message: 'Invalid service'
            });
        }

        // Check for conflicts
        const end_time = moment(start_time, 'HH:mm')
            .add(service.duration_minutes, 'minutes')
            .format('HH:mm');

        const conflicts = await db.query(`
            SELECT * FROM appointments
            WHERE staff_id = ?
            AND appointment_date = ?
            AND status NOT IN ('cancelled', 'no_show')
            AND (
                (start_time <= ? AND end_time > ?) OR
                (start_time < ? AND end_time >= ?) OR
                (start_time >= ? AND end_time <= ?)
            )
        `, [staff_id, appointment_date, start_time, start_time, end_time, end_time, start_time, end_time]);

        if (conflicts.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Time slot is not available for this staff member'
            });
        }

        // Create appointment
        const appointmentId = await db.create('appointments', {
            customer_id,
            staff_id,
            service_id,
            appointment_date,
            start_time,
            end_time,
            status: 'scheduled',
            notes
        });

        const newAppointment = await db.query(`
            SELECT a.*, 
                   c.first_name as customer_first_name,
                   c.last_name as customer_last_name,
                   s.name as service_name,
                   CONCAT(st.first_name, ' ', st.last_name) as staff_name
            FROM appointments a
            JOIN customers c ON a.customer_id = c.id
            JOIN services s ON a.service_id = s.id
            JOIN staff st ON a.staff_id = st.id
            WHERE a.id = ?
        `, [appointmentId]);

        res.status(201).json({
            success: true,
            message: 'Appointment created successfully',
            data: newAppointment[0]
        });
    } catch (error) {
        console.error('Create appointment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create appointment'
        });
    }
});

// Update appointment
router.put('/:id', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const appointmentId = req.params.id;
        const { status, notes } = req.body;

        const appointment = await db.findById('appointments', appointmentId);
        if (!appointment) {
            return res.status(404).json({
                success: false,
                message: 'Appointment not found'
            });
        }

        const updateData = {
            status,
            notes,
            updated_at: new Date()
        };

        await db.update('appointments', appointmentId, updateData);

        res.json({
            success: true,
            message: 'Appointment updated successfully'
        });
    } catch (error) {
        console.error('Update appointment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update appointment'
        });
    }
});

// Get available time slots
router.get('/available-slots', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const { staff_id, service_id, date } = req.query;

        if (!staff_id || !service_id || !date) {
            return res.status(400).json({
                success: false,
                message: 'Staff ID, service ID, and date are required'
            });
        }

        // Get service duration
        const [service] = await db.query(
            'SELECT duration_minutes FROM services WHERE id = ?',
            [service_id]
        );

        if (!service) {
            return res.status(400).json({
                success: false,
                message: 'Invalid service'
            });
        }

        // Get staff working hours (simplified - you might want to add a staff_schedule table)
        const workingHours = {
            start: '09:00',
            end: '18:00'
        };

        // Get existing appointments
        const existingAppointments = await db.query(`
            SELECT start_time, end_time
            FROM appointments
            WHERE staff_id = ?
            AND appointment_date = ?
            AND status NOT IN ('cancelled', 'no_show')
            ORDER BY start_time
        `, [staff_id, date]);

        // Generate available slots
        const availableSlots = [];
        const slotDuration = 30; // 30-minute slots
        const serviceDuration = service.duration_minutes;

        let currentTime = moment(workingHours.start, 'HH:mm');
        const endTime = moment(workingHours.end, 'HH:mm');

        while (currentTime.isBefore(endTime)) {
            const slotStart = currentTime.format('HH:mm');
            const slotEnd = currentTime.clone().add(serviceDuration, 'minutes').format('HH:mm');

            // Check if slot is within working hours
            if (moment(slotEnd, 'HH:mm').isAfter(endTime)) {
                break;
            }

            // Check for conflicts
            const hasConflict = existingAppointments.some(apt => {
                const aptStart = moment(apt.start_time, 'HH:mm');
                const aptEnd = moment(apt.end_time, 'HH:mm');
                
                return (
                    (moment(slotStart, 'HH:mm').isBefore(aptEnd) && moment(slotEnd, 'HH:mm').isAfter(aptStart))
                );
            });

            if (!hasConflict) {
                availableSlots.push({
                    time: slotStart,
                    end_time: slotEnd
                });
            }

            currentTime.add(slotDuration, 'minutes');
        }

        res.json({
            success: true,
            data: {
                availableSlots,
                serviceDuration
            }
        });
    } catch (error) {
        console.error('Get available slots error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch available slots'
        });
    }
});

// Get today's appointments
router.get('/today/summary', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const today = moment().format('YYYY-MM-DD');

        const [summary] = await db.query(`
            SELECT 
                COUNT(*) as total_appointments,
                SUM(CASE WHEN status = 'scheduled' THEN 1 ELSE 0 END) as scheduled,
                SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
                SUM(CASE WHEN status = 'no_show' THEN 1 ELSE 0 END) as no_show
            FROM appointments
            WHERE appointment_date = ?
        `, [today]);

        const appointments = await db.query(`
            SELECT a.*, 
                   c.first_name as customer_first_name,
                   c.last_name as customer_last_name,
                   s.name as service_name,
                   CONCAT(st.first_name, ' ', st.last_name) as staff_name
            FROM appointments a
            JOIN customers c ON a.customer_id = c.id
            JOIN services s ON a.service_id = s.id
            JOIN staff st ON a.staff_id = st.id
            WHERE a.appointment_date = ?
            ORDER BY a.start_time
        `, [today]);

        res.json({
            success: true,
            data: {
                summary: summary[0],
                appointments
            }
        });
    } catch (error) {
        console.error('Get today summary error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch today summary'
        });
    }
});

module.exports = router;