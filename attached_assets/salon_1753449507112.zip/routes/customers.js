const express = require('express');
const { db } = require('../config/database');
const { authenticateToken, requireReceptionist } = require('../middleware/auth');
const { customerValidation } = require('../middleware/validation');

const router = express.Router();

// Get all customers with pagination and search
router.get('/', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const { page = 1, limit = 10, search = '', sort = 'created_at', order = 'DESC' } = req.query;
        const offset = (page - 1) * limit;

        let sql = `
            SELECT c.*, 
                   CONCAT(s.first_name, ' ', s.last_name) as preferred_staff_name,
                   COUNT(a.id) as total_appointments,
                   SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) as completed_appointments
            FROM customers c
            LEFT JOIN staff s ON c.preferred_staff_id = s.id
            LEFT JOIN appointments a ON c.id = a.customer_id
            WHERE c.is_active = 1
        `;

        const params = [];

        if (search) {
            sql += ` AND (c.first_name LIKE ? OR c.last_name LIKE ? OR c.email LIKE ? OR c.phone LIKE ?)`;
            const searchTerm = `%${search}%`;
            params.push(searchTerm, searchTerm, searchTerm, searchTerm);
        }

        sql += ` GROUP BY c.id ORDER BY ${sort} ${order} LIMIT ? OFFSET ?`;
        params.push(parseInt(limit), parseInt(offset));

        const customers = await db.query(sql, params);

        // Get total count for pagination
        let countSql = 'SELECT COUNT(*) as total FROM customers WHERE is_active = 1';
        const countParams = [];
        
        if (search) {
            countSql += ` AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR phone LIKE ?)`;
            const searchTerm = `%${search}%`;
            countParams.push(searchTerm, searchTerm, searchTerm, searchTerm);
        }

        const [countResult] = await db.query(countSql, countParams);
        const total = countResult.total;

        res.json({
            success: true,
            data: {
                customers,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    pages: Math.ceil(total / limit)
                }
            }
        });
    } catch (error) {
        console.error('Get customers error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch customers'
        });
    }
});

// Get customer by ID
router.get('/:id', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const customerId = req.params.id;

        const [customer] = await db.query(`
            SELECT c.*, 
                   CONCAT(s.first_name, ' ', s.last_name) as preferred_staff_name
            FROM customers c
            LEFT JOIN staff s ON c.preferred_staff_id = s.id
            WHERE c.id = ? AND c.is_active = 1
        `, [customerId]);

        if (!customer) {
            return res.status(404).json({
                success: false,
                message: 'Customer not found'
            });
        }

        // Get customer preferences
        const preferences = await db.query(
            'SELECT * FROM customer_preferences WHERE customer_id = ?',
            [customerId]
        );

        // Get appointment history
        const appointments = await db.query(`
            SELECT a.*, 
                   s.name as service_name,
                   CONCAT(st.first_name, ' ', st.last_name) as staff_name,
                   sa.total_amount
            FROM appointments a
            JOIN services s ON a.service_id = s.id
            JOIN staff st ON a.staff_id = st.id
            LEFT JOIN sales sa ON a.id = sa.appointment_id
            WHERE a.customer_id = ?
            ORDER BY a.appointment_date DESC, a.start_time DESC
        `, [customerId]);

        // Get loyalty transactions
        const loyaltyTransactions = await db.query(`
            SELECT lt.*, s.total_amount
            FROM loyalty_transactions lt
            LEFT JOIN sales s ON lt.sale_id = s.id
            WHERE lt.customer_id = ?
            ORDER BY lt.created_at DESC
        `, [customerId]);

        res.json({
            success: true,
            data: {
                customer,
                preferences,
                appointments,
                loyaltyTransactions
            }
        });
    } catch (error) {
        console.error('Get customer error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch customer'
        });
    }
});

// Create new customer
router.post('/', authenticateToken, requireReceptionist, customerValidation.create, async (req, res) => {
    try {
        const customerData = {
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            email: req.body.email,
            phone: req.body.phone,
            address: req.body.address,
            date_of_birth: req.body.date_of_birth,
            gender: req.body.gender,
            notes: req.body.notes,
            preferred_staff_id: req.body.preferred_staff_id,
            loyalty_points: 0
        };

        const customerId = await db.create('customers', customerData);

        // Add preferences if provided
        if (req.body.preferences && Array.isArray(req.body.preferences)) {
            for (const pref of req.body.preferences) {
                await db.create('customer_preferences', {
                    customer_id: customerId,
                    preference_type: pref.type,
                    preference_value: pref.value
                });
            }
        }

        const newCustomer = await db.findById('customers', customerId);

        res.status(201).json({
            success: true,
            message: 'Customer created successfully',
            data: newCustomer
        });
    } catch (error) {
        console.error('Create customer error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create customer'
        });
    }
});

// Update customer
router.put('/:id', authenticateToken, requireReceptionist, customerValidation.update, async (req, res) => {
    try {
        const customerId = req.params.id;

        // Check if customer exists
        const existingCustomer = await db.findById('customers', customerId);
        if (!existingCustomer || !existingCustomer.is_active) {
            return res.status(404).json({
                success: false,
                message: 'Customer not found'
            });
        }

        const updateData = {
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            email: req.body.email,
            phone: req.body.phone,
            address: req.body.address,
            date_of_birth: req.body.date_of_birth,
            gender: req.body.gender,
            notes: req.body.notes,
            preferred_staff_id: req.body.preferred_staff_id,
            updated_at: new Date()
        };

        // Remove undefined values
        Object.keys(updateData).forEach(key => {
            if (updateData[key] === undefined) {
                delete updateData[key];
            }
        });

        await db.update('customers', customerId, updateData);

        // Update preferences if provided
        if (req.body.preferences && Array.isArray(req.body.preferences)) {
            // Delete existing preferences
            await db.query('DELETE FROM customer_preferences WHERE customer_id = ?', [customerId]);
            
            // Add new preferences
            for (const pref of req.body.preferences) {
                await db.create('customer_preferences', {
                    customer_id: customerId,
                    preference_type: pref.type,
                    preference_value: pref.value
                });
            }
        }

        const updatedCustomer = await db.findById('customers', customerId);

        res.json({
            success: true,
            message: 'Customer updated successfully',
            data: updatedCustomer
        });
    } catch (error) {
        console.error('Update customer error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update customer'
        });
    }
});

// Soft delete customer
router.delete('/:id', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const customerId = req.params.id;

        const existingCustomer = await db.findById('customers', customerId);
        if (!existingCustomer) {
            return res.status(404).json({
                success: false,
                message: 'Customer not found'
            });
        }

        await db.softDelete('customers', customerId);

        res.json({
            success: true,
            message: 'Customer deleted successfully'
        });
    } catch (error) {
        console.error('Delete customer error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete customer'
        });
    }
});

// Get customer loyalty points
router.get('/:id/loyalty', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const customerId = req.params.id;

        const [customer] = await db.query(
            'SELECT loyalty_points FROM customers WHERE id = ? AND is_active = 1',
            [customerId]
        );

        if (!customer) {
            return res.status(404).json({
                success: false,
                message: 'Customer not found'
            });
        }

        const transactions = await db.query(`
            SELECT lt.*, s.total_amount
            FROM loyalty_transactions lt
            LEFT JOIN sales s ON lt.sale_id = s.id
            WHERE lt.customer_id = ?
            ORDER BY lt.created_at DESC
        `, [customerId]);

        res.json({
            success: true,
            data: {
                currentPoints: customer.loyalty_points,
                transactions
            }
        });
    } catch (error) {
        console.error('Get loyalty points error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch loyalty points'
        });
    }
});

// Add loyalty points
router.post('/:id/loyalty', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const customerId = req.params.id;
        const { points, description } = req.body;

        if (!points || typeof points !== 'number') {
            return res.status(400).json({
                success: false,
                message: 'Valid points amount required'
            });
        }

        // Update customer points
        await db.query(
            'UPDATE customers SET loyalty_points = loyalty_points + ? WHERE id = ?',
            [points, customerId]
        );

        // Record transaction
        await db.create('loyalty_transactions', {
            customer_id: customerId,
            transaction_type: points > 0 ? 'earned' : 'adjusted',
            points: Math.abs(points),
            description: description || 'Manual adjustment'
        });

        res.json({
            success: true,
            message: 'Loyalty points updated successfully'
        });
    } catch (error) {
        console.error('Add loyalty points error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update loyalty points'
        });
    }
});

// Get customer appointment history
router.get('/:id/appointments', authenticateToken, requireReceptionist, async (req, res) => {
    try {
        const customerId = req.params.id;
        const { page = 1, limit = 10 } = req.query;
        const offset = (page - 1) * limit;

        const appointments = await db.query(`
            SELECT a.*, 
                   s.name as service_name,
                   s.duration_minutes,
                   CONCAT(st.first_name, ' ', st.last_name) as staff_name,
                   sa.total_amount,
                   sa.payment_method,
                   sa.payment_status
            FROM appointments a
            JOIN services s ON a.service_id = s.id
            JOIN staff st ON a.staff_id = st.id
            LEFT JOIN sales sa ON a.id = sa.appointment_id
            WHERE a.customer_id = ?
            ORDER BY a.appointment_date DESC, a.start_time DESC
            LIMIT ? OFFSET ?
        `, [customerId, parseInt(limit), parseInt(offset)]);

        const [countResult] = await db.query(
            'SELECT COUNT(*) as total FROM appointments WHERE customer_id = ?',
            [customerId]
        );

        res.json({
            success: true,
            data: {
                appointments,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: countResult.total,
                    pages: Math.ceil(countResult.total / limit)
                }
            }
        });
    } catch (error) {
        console.error('Get customer appointments error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch appointments'
        });
    }
});

module.exports = router;