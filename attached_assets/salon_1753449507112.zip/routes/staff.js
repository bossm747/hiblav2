const express = require('express');
const { db } = require('../config/database');
const { authenticateToken, requireManager } = require('../middleware/auth');

const router = express.Router();

// Get all staff members
router.get('/', authenticateToken, async (req, res) => {
    try {
        const { active_only = 'true' } = req.query;
        
        let sql = `
            SELECT s.*, u.username, u.email, u.role
            FROM staff s
            JOIN users u ON s.user_id = u.id
            WHERE 1=1
        `;
        
        if (active_only === 'true') {
            sql += ' AND s.is_active = 1';
        }
        
        sql += ' ORDER BY s.first_name, s.last_name';
        
        const staff = await db.query(sql);
        
        res.json({
            success: true,
            data: staff
        });
    } catch (error) {
        console.error('Get staff error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch staff'
        });
    }
});

// Get staff availability
router.get('/:id/availability', authenticateToken, async (req, res) => {
    try {
        const staffId = req.params.id;
        const { date } = req.query;
        
        // Get staff work schedule
        const schedule = await db.query(`
            SELECT * FROM staff_schedules
            WHERE staff_id = ? AND is_active = 1
            ORDER BY day_of_week
        `, [staffId]);
        
        // Get existing appointments for the date
        let appointments = [];
        if (date) {
            appointments = await db.query(`
                SELECT start_time, end_time
                FROM appointments
                WHERE staff_id = ? AND appointment_date = ? AND status IN ('scheduled', 'confirmed', 'in_progress')
            `, [staffId, date]);
        }
        
        res.json({
            success: true,
            data: {
                schedule,
                appointments
            }
        });
    } catch (error) {
        console.error('Get availability error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch availability'
        });
    }
});

// Create new staff member
router.post('/', authenticateToken, requireManager, async (req, res) => {
    try {
        const { user_id, first_name, last_name, phone, address, hourly_rate, commission_rate, specialties } = req.body;
        
        const staffId = await db.create('staff', {
            user_id,
            first_name,
            last_name,
            phone,
            address,
            hourly_rate,
            commission_rate,
            specialties: JSON.stringify(specialties || [])
        });
        
        const newStaff = await db.query(`
            SELECT s.*, u.username, u.email
            FROM staff s
            JOIN users u ON s.user_id = u.id
            WHERE s.id = ?
        `, [staffId]);
        
        res.status(201).json({
            success: true,
            message: 'Staff member created successfully',
            data: newStaff[0]
        });
    } catch (error) {
        console.error('Create staff error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create staff member'
        });
    }
});

module.exports = router;