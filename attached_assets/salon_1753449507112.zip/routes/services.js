const express = require('express');
const { db } = require('../config/database');
const { authenticateToken, requireManager } = require('../middleware/auth');

const router = express.Router();

// Get all services with categories
router.get('/', authenticateToken, async (req, res) => {
    try {
        const { category_id, active_only = 'true' } = req.query;
        
        let sql = `
            SELECT s.*, sc.name as category_name, sc.color_code
            FROM services s
            JOIN service_categories sc ON s.category_id = sc.id
            WHERE 1=1
        `;
        
        const params = [];
        
        if (active_only === 'true') {
            sql += ' AND s.is_active = 1';
        }
        
        if (category_id) {
            sql += ' AND s.category_id = ?';
            params.push(category_id);
        }
        
        sql += ' ORDER BY sc.name, s.name';
        
        const services = await db.query(sql, params);
        
        res.json({
            success: true,
            data: services
        });
    } catch (error) {
        console.error('Get services error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch services'
        });
    }
});

// Get service categories
router.get('/categories', authenticateToken, async (req, res) => {
    try {
        const categories = await db.query(`
            SELECT sc.*, COUNT(s.id) as service_count
            FROM service_categories sc
            LEFT JOIN services s ON sc.id = s.category_id AND s.is_active = 1
            WHERE sc.is_active = 1
            GROUP BY sc.id
            ORDER BY sc.name
        `);
        
        res.json({
            success: true,
            data: categories
        });
    } catch (error) {
        console.error('Get categories error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch categories'
        });
    }
});

// Create new service
router.post('/', authenticateToken, requireManager, async (req, res) => {
    try {
        const { category_id, name, description, duration_minutes, base_price, commission_rate } = req.body;
        
        const serviceId = await db.create('services', {
            category_id,
            name,
            description,
            duration_minutes,
            base_price,
            commission_rate
        });
        
        const newService = await db.query(`
            SELECT s.*, sc.name as category_name
            FROM services s
            JOIN service_categories sc ON s.category_id = sc.id
            WHERE s.id = ?
        `, [serviceId]);
        
        res.status(201).json({
            success: true,
            message: 'Service created successfully',
            data: newService[0]
        });
    } catch (error) {
        console.error('Create service error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create service'
        });
    }
});

// Update service
router.put('/:id', authenticateToken, requireManager, async (req, res) => {
    try {
        const serviceId = req.params.id;
        const { name, description, duration_minutes, base_price, commission_rate, is_active } = req.body;
        
        const service = await db.findById('services', serviceId);
        if (!service) {
            return res.status(404).json({
                success: false,
                message: 'Service not found'
            });
        }
        
        await db.update('services', serviceId, {
            name,
            description,
            duration_minutes,
            base_price,
            commission_rate,
            is_active
        });
        
        res.json({
            success: true,
            message: 'Service updated successfully'
        });
    } catch (error) {
        console.error('Update service error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update service'
        });
    }
});

module.exports = router;