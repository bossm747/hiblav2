const mysql = require('mysql2/promise');
require('dotenv').config();

// Database configuration
const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'salon_spa_db',
    port: process.env.DB_PORT || 3306,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    acquireTimeout: 60000,
    timeout: 60000,
    reconnect: true
};

// Create connection pool
const pool = mysql.createPool(dbConfig);

// Test database connection
async function testConnection() {
    try {
        const connection = await pool.getConnection();
        console.log('✅ Database connected successfully');
        connection.release();
        return true;
    } catch (error) {
        console.error('❌ Database connection failed:', error.message);
        return false;
    }
}

// Initialize database (create tables if they don't exist)
async function initializeDatabase() {
    try {
        // First, create database if it doesn't exist
        const tempPool = mysql.createPool({
            ...dbConfig,
            database: undefined
        });
        
        await tempPool.execute(`CREATE DATABASE IF NOT EXISTS ${dbConfig.database}`);
        await tempPool.end();
        
        // Now create tables
        const fs = require('fs');
        const path = require('path');
        const schemaPath = path.join(__dirname, '..', 'database_schema.sql');
        
        if (fs.existsSync(schemaPath)) {
            const schema = fs.readFileSync(schemaPath, 'utf8');
            const statements = schema.split(';').filter(stmt => stmt.trim());
            
            for (const statement of statements) {
                if (statement.trim()) {
                    await pool.execute(statement);
                }
            }
            console.log('✅ Database schema initialized');
        }
        
        return true;
    } catch (error) {
        console.error('❌ Database initialization failed:', error.message);
        return false;
    }
}

// Generic query function with error handling
async function query(sql, params = []) {
    try {
        const [results] = await pool.execute(sql, params);
        return results;
    } catch (error) {
        console.error('Database query error:', error.message);
        throw error;
    }
}

// Transaction helper
async function transaction(callback) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const result = await callback(connection);
        await connection.commit();
        return result;
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
    }
}

// Common database operations
const db = {
    // Basic CRUD operations
    async findById(table, id) {
        const sql = `SELECT * FROM ${table} WHERE id = ?`;
        const results = await query(sql, [id]);
        return results[0] || null;
    },

    async findAll(table, conditions = {}, orderBy = 'id ASC', limit = null) {
        let sql = `SELECT * FROM ${table}`;
        const params = [];

        if (Object.keys(conditions).length > 0) {
            const whereClause = Object.keys(conditions)
                .map(key => `${key} = ?`)
                .join(' AND ');
            sql += ` WHERE ${whereClause}`;
            params.push(...Object.values(conditions));
        }

        sql += ` ORDER BY ${orderBy}`;
        
        if (limit) {
            sql += ` LIMIT ${limit}`;
        }

        return await query(sql, params);
    },

    async create(table, data) {
        const columns = Object.keys(data).join(', ');
        const placeholders = Object.keys(data).map(() => '?').join(', ');
        const sql = `INSERT INTO ${table} (${columns}) VALUES (${placeholders})`;
        
        const result = await query(sql, Object.values(data));
        return result.insertId;
    },

    async update(table, id, data) {
        const setClause = Object.keys(data)
            .map(key => `${key} = ?`)
            .join(', ');
        const sql = `UPDATE ${table} SET ${setClause} WHERE id = ?`;
        
        const result = await query(sql, [...Object.values(data), id]);
        return result.affectedRows > 0;
    },

    async delete(table, id) {
        const sql = `DELETE FROM ${table} WHERE id = ?`;
        const result = await query(sql, [id]);
        return result.affectedRows > 0;
    },

    // Soft delete (set is_active = false)
    async softDelete(table, id) {
        return await this.update(table, id, { is_active: false });
    },

    // Custom query execution
    query,
    transaction,
    pool
};

module.exports = {
    db,
    testConnection,
    initializeDatabase
};