const express = require('express');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// API Routes (mock data for demo)
app.get('/api/dashboard', (req, res) => {
    res.json({
        success: true,
        data: {
            todayAppointments: 12,
            todayRevenue: 2450,
            totalCustomers: 342,
            monthlyGrowth: 15
        }
    });
});

// Serve the frontend
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log('Salon & Spa Management System is ready!');
});