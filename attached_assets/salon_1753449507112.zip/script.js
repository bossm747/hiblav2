// Salon & Spa Management System - Main JavaScript

// Global variables
let currentUser = null;
let currentPage = 'dashboard';
let customers = [];
let appointments = [];
let services = [];
let staff = [];
let products = [];
let sales = [];

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    loadSampleData();
    setupEventListeners();
    showLoginScreen();
}

// Sample data for demonstration
function loadSampleData() {
    customers = [
        { id: 1, name: 'Emma Johnson', email: 'emma@email.com', phone: '555-0123', totalVisits: 12, totalSpent: 1250.00, lastVisit: '2024-01-15' },
        { id: 2, name: 'Michael Chen', email: 'michael@email.com', phone: '555-0124', totalVisits: 8, totalSpent: 890.00, lastVisit: '2024-01-14' },
        { id: 3, name: 'Sarah Williams', email: 'sarah@email.com', phone: '555-0125', totalVisits: 15, totalSpent: 2100.00, lastVisit: '2024-01-13' },
        { id: 4, name: 'David Martinez', email: 'david@email.com', phone: '555-0126', totalVisits: 5, totalSpent: 450.00, lastVisit: '2024-01-12' }
    ];

    services = [
        { id: 1, name: 'Haircut & Style', category: 'Hair', price: 65.00, duration: 45, description: 'Professional haircut with styling' },
        { id: 2, name: 'Full Body Massage', category: 'Massage', price: 120.00, duration: 60, description: 'Relaxing full body massage' },
        { id: 3, name: 'Facial Treatment', category: 'Skincare', price: 85.00, duration: 50, description: 'Deep cleansing facial treatment' },
        { id: 4, name: 'Manicure & Pedicure', category: 'Nails', price: 55.00, duration: 60, description: 'Complete nail care service' },
        { id: 5, name: 'Hair Color', category: 'Hair', price: 95.00, duration: 90, description: 'Professional hair coloring' }
    ];

    staff = [
        { id: 1, name: 'Lisa Anderson', role: 'Senior Stylist', email: 'lisa@salon.com', phone: '555-0201', specialties: ['Haircut', 'Color', 'Styling'] },
        { id: 2, name: 'James Wilson', role: 'Massage Therapist', email: 'james@salon.com', phone: '555-0202', specialties: ['Massage', 'Aromatherapy'] },
        { id: 3, name: 'Maria Rodriguez', role: 'Esthetician', email: 'maria@salon.com', phone: '555-0203', specialties: ['Facials', 'Skincare', 'Waxing'] },
        { id: 4, name: 'Kevin Lee', role: 'Nail Technician', email: 'kevin@salon.com', phone: '555-0204', specialties: ['Manicure', 'Pedicure', 'Nail Art'] }
    ];

    appointments = [
        { id: 1, customerId: 1, customerName: 'Emma Johnson', serviceId: 1, serviceName: 'Haircut & Style', staffId: 1, staffName: 'Lisa Anderson', date: '2024-01-16', time: '09:00', duration: 45, status: 'confirmed', notes: 'Regular client, prefers layers' },
        { id: 2, customerId: 2, customerName: 'Michael Chen', serviceId: 2, serviceName: 'Full Body Massage', staffId: 2, staffName: 'James Wilson', date: '2024-01-16', time: '10:30', duration: 60, status: 'confirmed', notes: 'First time client' },
        { id: 3, customerId: 3, customerName: 'Sarah Williams', serviceId: 3, serviceName: 'Facial Treatment', staffId: 3, staffName: 'Maria Rodriguez', date: '2024-01-16', time: '14:00', duration: 50, status: 'pending', notes: 'Sensitive skin' },
        { id: 4, customerId: 4, customerName: 'David Martinez', serviceId: 4, serviceName: 'Manicure & Pedicure', staffId: 4, staffName: 'Kevin Lee', date: '2024-01-17', time: '11:00', duration: 60, status: 'confirmed', notes: 'Gel manicure requested' }
    ];

    products = [
        { id: 1, name: 'Shampoo Premium', category: 'Hair Care', price: 25.00, stock: 50, minStock: 10, supplier: 'Beauty Supply Co' },
        { id: 2, name: 'Conditioner Hydrating', category: 'Hair Care', price: 28.00, stock: 35, minStock: 10, supplier: 'Beauty Supply Co' },
        { id: 3, name: 'Face Cream Anti-Aging', category: 'Skincare', price: 45.00, stock: 25, minStock: 5, supplier: 'Skin Solutions' },
        { id: 4, name: 'Massage Oil Lavender', category: 'Massage', price: 18.00, stock: 40, minStock: 10, supplier: 'Aromatherapy Plus' },
        { id: 5, name: 'Nail Polish Set', category: 'Nails', price: 35.00, stock: 60, minStock: 15, supplier: 'Nail Art Supplies' }
    ];

    sales = [
        { id: 1, date: '2024-01-15', customerName: 'Emma Johnson', items: [{ name: 'Shampoo Premium', quantity: 1, price: 25.00 }], total: 25.00, paymentMethod: 'Card' },
        { id: 2, date: '2024-01-14', customerName: 'Michael Chen', items: [{ name: 'Massage Oil Lavender', quantity: 2, price: 18.00 }], total: 36.00, paymentMethod: 'Cash' },
        { id: 3, date: '2024-01-13', customerName: 'Sarah Williams', items: [{ name: 'Face Cream Anti-Aging', quantity: 1, price: 45.00 }], total: 45.00, paymentMethod: 'Card' }
    ];
}

// Event Listeners
function setupEventListeners() {
    // Login form
    document.getElementById('login-form').addEventListener('submit', handleLogin);
    
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = e.target.dataset.page;
            if (page) {
                showPage(page);
            }
        });
    });

    // Logout
    document.getElementById('logout-btn').addEventListener('click', handleLogout);

    // Search functionality
    document.querySelectorAll('.search-input').forEach(input => {
        input.addEventListener('input', handleSearch);
    });

    // Modal close buttons
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', closeModal);
    });

    // Form submissions
    document.addEventListener('submit', handleFormSubmit);
}

// Authentication
function handleLogin(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Simple demo authentication
    if (username === 'admin' && password === 'admin123') {
        currentUser = { username: 'admin', role: 'admin', name: 'Admin User' };
        showApp();
    } else if (username === 'staff' && password === 'staff123') {
        currentUser = { username: 'staff', role: 'staff', name: 'Staff User' };
        showApp();
    } else {
        alert('Invalid credentials. Try admin/admin123 or staff/staff123');
    }
}

function handleLogout() {
    currentUser = null;
    showLoginScreen();
}

function showLoginScreen() {
    document.getElementById('login-screen').style.display = 'flex';
    document.getElementById('main-app').style.display = 'none';
}

function showApp() {
    document.getElementById('login-screen').style.display = 'none';
    document.getElementById('main-app').style.display = 'flex';
    document.getElementById('user-name').textContent = currentUser.name;
    showPage('dashboard');
}

// Page Navigation
function showPage(page) {
    currentPage = page;
    
    // Hide all pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    
    // Show selected page
    document.getElementById(`${page}Page`).classList.add('active');
    
    // Update navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.dataset.page === page) {
            link.classList.add('active');
        }
    });

    // Load page-specific data
    loadPageData(page);
}

function loadPageData(page) {
    switch (page) {
        case 'dashboard':
            loadDashboardData();
            break;
        case 'customers':
            loadCustomersTable();
            break;
        case 'appointments':
            loadAppointmentsTable();
            break;
        case 'services':
            loadServicesTable();
            break;
        case 'staff':
            loadStaffTable();
            break;
        case 'inventory':
            loadInventoryTable();
            break;
        case 'pos':
            loadPOSData();
            break;
        case 'reports':
            loadReportsData();
            break;
    }
}

// Dashboard
function loadDashboardData() {
    const today = new Date().toISOString().split('T')[0];
    const todayAppointments = appointments.filter(a => a.date === today);
    const pendingAppointments = appointments.filter(a => a.status === 'pending');
    const lowStockProducts = products.filter(p => p.stock <= p.minStock);

    document.getElementById('todayAppointments').textContent = todayAppointments.length;
    document.getElementById('totalCustomers').textContent = customers.length;
    document.getElementById('totalRevenue').textContent = `$${calculateTotalRevenue().toFixed(2)}`;
    document.getElementById('pendingAppointments').textContent = pendingAppointments.length;

    // Recent appointments
    const recentAppointmentsList = document.getElementById('recentAppointments');
    recentAppointmentsList.innerHTML = '';
    appointments.slice(0, 5).forEach(appointment => {
        const li = document.createElement('li');
        li.className = 'appointment-item';
        li.innerHTML = `
            <div>
                <strong>${appointment.customerName}</strong>
                <br><small>${appointment.serviceName} - ${appointment.time}</small>
            </div>
            <span class="status ${appointment.status}">${appointment.status}</span>
        `;
        recentAppointmentsList.appendChild(li);
    });

    // Recent activities
    const recentActivitiesList = document.getElementById('recentActivities');
    recentActivitiesList.innerHTML = '';
    sales.slice(0, 5).forEach(sale => {
        const li = document.createElement('li');
        li.className = 'activity-item';
        li.innerHTML = `
            <i class="fas fa-shopping-cart"></i>
            <div>
                <strong>${sale.customerName}</strong> purchased items worth $${sale.total}
                <br><small>${sale.date}</small>
            </div>
        `;
        recentActivitiesList.appendChild(li);
    });
}

// Customers
function loadCustomersTable() {
    const tbody = document.querySelector('#customersTable tbody');
    tbody.innerHTML = '';
    
    customers.forEach(customer => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${customer.id}</td>
            <td>${customer.name}</td>
            <td>${customer.email}</td>
            <td>${customer.phone}</td>
            <td>${customer.totalVisits}</td>
            <td>$${customer.totalSpent.toFixed(2)}</td>
            <td>${customer.lastVisit}</td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="editCustomer(${customer.id})">Edit</button>
                <button class="btn btn-sm btn-outline" onclick="viewCustomer(${customer.id})">View</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Appointments
function loadAppointmentsTable() {
    const tbody = document.querySelector('#appointmentsTable tbody');
    tbody.innerHTML = '';
    
    appointments.forEach(appointment => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${appointment.id}</td>
            <td>${appointment.customerName}</td>
            <td>${appointment.serviceName}</td>
            <td>${appointment.staffName}</td>
            <td>${appointment.date}</td>
            <td>${appointment.time}</td>
            <td><span class="status ${appointment.status}">${appointment.status}</span></td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="editAppointment(${appointment.id})">Edit</button>
                <button class="btn btn-sm btn-outline" onclick="cancelAppointment(${appointment.id})">Cancel</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Services
function loadServicesTable() {
    const tbody = document.querySelector('#servicesTable tbody');
    tbody.innerHTML = '';
    
    services.forEach(service => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${service.id}</td>
            <td>${service.name}</td>
            <td>${service.category}</td>
            <td>$${service.price.toFixed(2)}</td>
            <td>${service.duration} min</td>
            <td>${service.description}</td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="editService(${service.id})">Edit</button>
                <button class="btn btn-sm btn-outline" onclick="deleteService(${service.id})">Delete</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Staff
function loadStaffTable() {
    const tbody = document.querySelector('#staffTable tbody');
    tbody.innerHTML = '';
    
    staff.forEach(member => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${member.id}</td>
            <td>${member.name}</td>
            <td>${member.role}</td>
            <td>${member.email}</td>
            <td>${member.phone}</td>
            <td>${member.specialties.join(', ')}</td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="editStaff(${member.id})">Edit</button>
                <button class="btn btn-sm btn-outline" onclick="viewSchedule(${member.id})">Schedule</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Inventory
function loadInventoryTable() {
    const tbody = document.querySelector('#inventoryTable tbody');
    tbody.innerHTML = '';
    
    products.forEach(product => {
        const tr = document.createElement('tr');
        const isLowStock = product.stock <= product.minStock;
        tr.innerHTML = `
            <td>${product.id}</td>
            <td>${product.name}</td>
            <td>${product.category}</td>
            <td>$${product.price.toFixed(2)}</td>
            <td class="${isLowStock ? 'text-danger' : ''}">${product.stock}</td>
            <td>${product.minStock}</td>
            <td>${product.supplier}</td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="editProduct(${product.id})">Edit</button>
                <button class="btn btn-sm btn-outline" onclick="restockProduct(${product.id})">Restock</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// POS
function loadPOSData() {
    const servicesSelect = document.getElementById('posServices');
    servicesSelect.innerHTML = '<option value="">Select Service</option>';
    services.forEach(service => {
        const option = document.createElement('option');
        option.value = service.id;
        option.textContent = `${service.name} - $${service.price}`;
        servicesSelect.appendChild(option);
    });

    const productsSelect = document.getElementById('posProducts');
    productsSelect.innerHTML = '<option value="">Select Product</option>';
    products.forEach(product => {
        const option = document.createElement('option');
        option.value = product.id;
        option.textContent = `${product.name} - $${product.price}`;
        productsSelect.appendChild(option);
    });
}

// Reports
function loadReportsData() {
    const totalRevenue = calculateTotalRevenue();
    const totalSales = sales.length;
    const avgOrderValue = totalRevenue / totalSales;
    
    document.getElementById('reportTotalRevenue').textContent = `$${totalRevenue.toFixed(2)}`;
    document.getElementById('reportTotalSales').textContent = totalSales;
    document.getElementById('reportAvgOrder').textContent = `$${avgOrderValue.toFixed(2)}`;
    document.getElementById('reportTotalCustomers').textContent = customers.length;
}

// Utility Functions
function calculateTotalRevenue() {
    return sales.reduce((total, sale) => total + sale.total, 0);
}

function handleSearch(e) {
    const searchTerm = e.target.value.toLowerCase();
    const table = e.target.closest('.card').querySelector('.data-table');
    const rows = table.querySelectorAll('tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

function handleFormSubmit(e) {
    e.preventDefault();
    // Handle form submissions based on form ID
    console.log('Form submitted:', e.target.id);
}

function closeModal() {
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.style.display = 'none';
    });
}

// Modal functions
function showModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}

// Quick actions
function addCustomer() {
    showModal('customerModal');
}

function addAppointment() {
    showModal('appointmentModal');
}

function addService() {
    showModal('serviceModal');
}

function addStaff() {
    showModal('staffModal');
}

function addProduct() {
    showModal('productModal');
}

// Initialize
function init() {
    // Load initial data
    loadDashboardData();
}

// Start the app
init();