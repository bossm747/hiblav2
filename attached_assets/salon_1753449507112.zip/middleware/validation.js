const { body, param, query, validationResult } = require('express-validator');

// Handle validation errors
const handleValidationErrors = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validation failed',
            errors: errors.array()
        });
    }
    next();
};

// Common validation rules
const commonValidations = {
    id: param('id').isInt({ min: 1 }).withMessage('ID must be a positive integer'),
    email: body('email').isEmail().normalizeEmail().withMessage('Valid email is required'),
    phone: body('phone').optional().isMobilePhone().withMessage('Valid phone number required'),
    password: body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    name: body('name').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters'),
    firstName: body('first_name').trim().isLength({ min: 2 }).withMessage('First name must be at least 2 characters'),
    lastName: body('last_name').trim().isLength({ min: 2 }).withMessage('Last name must be at least 2 characters'),
    date: body('date').isISO8601().withMessage('Valid date required (YYYY-MM-DD)'),
    time: body('time').matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).withMessage('Valid time required (HH:MM)'),
    price: body('price').isFloat({ min: 0 }).withMessage('Price must be a positive number'),
    quantity: body('quantity').isInt({ min: 1 }).withMessage('Quantity must be a positive integer')
};

// User validation rules
const userValidation = {
    register: [
        body('username').trim().isLength({ min: 3 }).withMessage('Username must be at least 3 characters'),
        commonValidations.email,
        commonValidations.password,
        body('role').isIn(['admin', 'manager', 'staff', 'receptionist']).withMessage('Invalid role'),
        handleValidationErrors
    ],
    
    login: [
        body('username').trim().notEmpty().withMessage('Username is required'),
        body('password').notEmpty().withMessage('Password is required'),
        handleValidationErrors
    ],
    
    updateProfile: [
        commonValidations.email.optional(),
        body('username').optional().trim().isLength({ min: 3 }).withMessage('Username must be at least 3 characters'),
        handleValidationErrors
    ],
    
    changePassword: [
        body('currentPassword').notEmpty().withMessage('Current password is required'),
        body('newPassword').isLength({ min: 6 }).withMessage('New password must be at least 6 characters'),
        handleValidationErrors
    ]
};

// Customer validation rules
const customerValidation = {
    create: [
        commonValidations.firstName,
        commonValidations.lastName,
        commonValidations.email.optional(),
        commonValidations.phone.optional(),
        body('date_of_birth').optional().isISO8601().withMessage('Valid birth date required'),
        body('gender').optional().isIn(['male', 'female', 'other']).withMessage('Invalid gender'),
        handleValidationErrors
    ],
    
    update: [
        commonValidations.id,
        commonValidations.firstName.optional(),
        commonValidations.lastName.optional(),
        commonValidations.email.optional(),
        commonValidations.phone.optional(),
        body('date_of_birth').optional().isISO8601().withMessage('Valid birth date required'),
        body('gender').optional().isIn(['male', 'female', 'other']).withMessage('Invalid gender'),
        handleValidationErrors
    ]
};

// Staff validation rules
const staffValidation = {
    create: [
        commonValidations.firstName,
        commonValidations.lastName,
        commonValidations.phone.optional(),
        body('hire_date').optional().isISO8601().withMessage('Valid hire date required'),
        body('hourly_rate').optional().isFloat({ min: 0 }).withMessage('Hourly rate must be positive'),
        body('commission_rate').optional().isFloat({ min: 0, max: 100 }).withMessage('Commission rate must be between 0-100'),
        handleValidationErrors
    ],
    
    update: [
        commonValidations.id,
        commonValidations.firstName.optional(),
        commonValidations.lastName.optional(),
        commonValidations.phone.optional(),
        body('hire_date').optional().isISO8601().withMessage('Valid hire date required'),
        body('hourly_rate').optional().isFloat({ min: 0 }).withMessage('Hourly rate must be positive'),
        body('commission_rate').optional().isFloat({ min: 0, max: 100 }).withMessage('Commission rate must be between 0-100'),
        handleValidationErrors
    ]
};

// Service validation rules
const serviceValidation = {
    create: [
        commonValidations.name,
        body('category_id').isInt({ min: 1 }).withMessage('Valid category ID required'),
        body('duration_minutes').isInt({ min: 1 }).withMessage('Duration must be positive'),
        commonValidations.price.withMessage('Base price required'),
        body('commission_rate').optional().isFloat({ min: 0, max: 100 }).withMessage('Commission rate must be between 0-100'),
        handleValidationErrors
    ],
    
    update: [
        commonValidations.id,
        commonValidations.name.optional(),
        body('category_id').optional().isInt({ min: 1 }).withMessage('Valid category ID required'),
        body('duration_minutes').optional().isInt({ min: 1 }).withMessage('Duration must be positive'),
        body('base_price').optional().isFloat({ min: 0 }).withMessage('Base price must be positive'),
        body('commission_rate').optional().isFloat({ min: 0, max: 100 }).withMessage('Commission rate must be between 0-100'),
        handleValidationErrors
    ]
};

// Appointment validation rules
const appointmentValidation = {
    create: [
        body('customer_id').isInt({ min: 1 }).withMessage('Valid customer ID required'),
        body('staff_id').isInt({ min: 1 }).withMessage('Valid staff ID required'),
        body('service_id').isInt({ min: 1 }).withMessage('Valid service ID required'),
        body('appointment_date').isISO8601().withMessage('Valid appointment date required'),
        body('start_time').matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).withMessage('Valid start time required'),
        handleValidationErrors
    ],
    
    update: [
        commonValidations.id,
        body('customer_id').optional().isInt({ min: 1 }).withMessage('Valid customer ID required'),
        body('staff_id').optional().isInt({ min: 1 }).withMessage('Valid staff ID required'),
        body('service_id').optional().isInt({ min: 1 }).withMessage('Valid service ID required'),
        body('appointment_date').optional().isISO8601().withMessage('Valid appointment date required'),
        body('start_time').optional().matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).withMessage('Valid start time required'),
        body('status').optional().isIn(['scheduled', 'confirmed', 'in_progress', 'completed', 'cancelled', 'no_show']).withMessage('Invalid status'),
        handleValidationErrors
    ]
};

// Product validation rules
const productValidation = {
    create: [
        commonValidations.name,
        body('category_id').isInt({ min: 1 }).withMessage('Valid category ID required'),
        body('sku').optional().trim().isLength({ min: 1 }).withMessage('SKU cannot be empty'),
        body('cost_price').optional().isFloat({ min: 0 }).withMessage('Cost price must be positive'),
        body('selling_price').isFloat({ min: 0 }).withMessage('Selling price must be positive'),
        body('current_stock').optional().isInt({ min: 0 }).withMessage('Stock must be non-negative'),
        handleValidationErrors
    ],
    
    update: [
        commonValidations.id,
        commonValidations.name.optional(),
        body('category_id').optional().isInt({ min: 1 }).withMessage('Valid category ID required'),
        body('sku').optional().trim().isLength({ min: 1 }).withMessage('SKU cannot be empty'),
        body('cost_price').optional().isFloat({ min: 0 }).withMessage('Cost price must be positive'),
        body('selling_price').optional().isFloat({ min: 0 }).withMessage('Selling price must be positive'),
        body('current_stock').optional().isInt({ min: 0 }).withMessage('Stock must be non-negative'),
        handleValidationErrors
    ]
};

// Sale validation rules
const saleValidation = {
    create: [
        body('customer_id').optional().isInt({ min: 1 }).withMessage('Valid customer ID required'),
        body('staff_id').isInt({ min: 1 }).withMessage('Valid staff ID required'),
        body('items').isArray({ min: 1 }).withMessage('At least one item required'),
        body('items.*.item_type').isIn(['service', 'product']).withMessage('Invalid item type'),
        body('items.*.item_id').isInt({ min: 1 }).withMessage('Valid item ID required'),
        body('items.*.quantity').isInt({ min: 1 }).withMessage('Quantity must be positive'),
        body('items.*.unit_price').isFloat({ min: 0 }).withMessage('Unit price must be positive'),
        body('payment_method').isIn(['cash', 'card', 'check', 'gift_card', 'loyalty_points']).withMessage('Invalid payment method'),
        handleValidationErrors
    ]
};

// Query parameter validation
const queryValidation = {
    pagination: [
        query('page').optional().isInt({ min: 1 }).withMessage('Page must be positive integer'),
        query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1-100'),
        handleValidationErrors
    ],
    
    dateRange: [
        query('start_date').optional().isISO8601().withMessage('Valid start date required'),
        query('end_date').optional().isISO8601().withMessage('Valid end date required'),
        handleValidationErrors
    ]
};

module.exports = {
    handleValidationErrors,
    userValidation,
    customerValidation,
    staffValidation,
    serviceValidation,
    appointmentValidation,
    productValidation,
    saleValidation,
    queryValidation,
    commonValidations
};